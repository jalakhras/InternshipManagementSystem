using InternshipManagementSystem.Samples;

namespace InternshipManagementSystem.EntityFrameworkCore.Domains;

//[Collection(InternshipManagementSystemTestConsts.CollectionDefinitionName)]
public class EfCoreSampleDomainTests : SampleDomainTests<InternshipManagementSystemEntityFrameworkCoreTestModule>
{
}