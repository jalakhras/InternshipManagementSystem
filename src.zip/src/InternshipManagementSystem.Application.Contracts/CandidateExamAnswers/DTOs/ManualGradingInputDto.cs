﻿namespace InternshipManagementSystem.CandidateExamAnswers.DTOs
{
    public class ManualGradingInputDto
    {
        public double PartialScore { get; set; }
        public string? ReviewComments { get; set; }
    }
}
