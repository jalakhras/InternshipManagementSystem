﻿namespace InternshipManagementSystem.TrainingManagement.Users
{
    internal class IUserAppService
    {
    }
}