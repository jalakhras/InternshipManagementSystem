﻿namespace InternshipManagementSystem.TrainingManagement.DTOs.Questions
{
    public enum QuestionType
    {
        MultipleChoice = 0, // سؤال اختيار من متعدد
        TrueFalse = 1,      // سؤال صح وخطأ
        Text = 2            // سؤال نصي
    }
}