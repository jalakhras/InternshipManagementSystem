﻿namespace InternshipManagementSystem.TrainingManagement.DTOs.Specializations
{
    public class CreateUpdateSpecializationDto
    {
        public string Name { get; set; }
    }
}