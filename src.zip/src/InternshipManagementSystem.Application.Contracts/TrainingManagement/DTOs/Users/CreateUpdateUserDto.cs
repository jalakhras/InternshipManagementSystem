﻿namespace InternshipManagementSystem.TrainingManagement.DTOs.Users
{
    internal class CreateUpdateUserDto
    {
    }
}