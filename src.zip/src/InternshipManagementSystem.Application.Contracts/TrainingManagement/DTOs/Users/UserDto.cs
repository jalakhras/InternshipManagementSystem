﻿namespace InternshipManagementSystem.TrainingManagement.DTOs.Users
{
    internal class UserDto
    {
    }
}