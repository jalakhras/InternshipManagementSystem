﻿namespace InternshipManagementSystem.TrainingManagement.Registration.Constants
{
    public static class RoleNames
    {
        public const string Admin = "Admin";
        public const string Supervisor = "Supervisor";
        public const string Trainee = "Trainee";
    }
}