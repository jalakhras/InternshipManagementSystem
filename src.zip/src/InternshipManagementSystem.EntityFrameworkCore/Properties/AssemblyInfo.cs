﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleToAttribute("InternshipManagementSystem.EntityFrameworkCore.Tests")]