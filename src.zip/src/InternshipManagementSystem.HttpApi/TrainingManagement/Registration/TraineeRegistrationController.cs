﻿namespace InternshipManagementSystem.TrainingManagement.Registration
{
    internal class TraineeRegistrationController
    {
    }
}