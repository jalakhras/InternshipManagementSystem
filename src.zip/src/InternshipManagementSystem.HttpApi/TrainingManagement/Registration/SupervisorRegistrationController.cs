﻿namespace InternshipManagementSystem.TrainingManagement.Registration
{
    internal class SupervisorRegistrationController
    {
    }
}