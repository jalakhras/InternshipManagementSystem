﻿using Volo.Abp.Localization;

namespace InternshipManagementSystem.Localization;

[LocalizationResourceName("InternshipManagementSystem")]
public class InternshipManagementSystemResource
{
}