﻿namespace InternshipManagementSystem.TrainingManagement.Enums
{
    public enum MediaType
    {
        Image,
        Audio,
        Video,
        Document
    }
}