﻿namespace InternshipManagementSystem;

public static class InternshipManagementSystemDomainErrorCodes
{
    /* You can add your business exception error codes here, as constants */
}