﻿namespace InternshipManagementSystem.Settings
{
    public static class InternshipManagementSystemSettings
    {
        private const string Prefix = "InternshipManagementSystem";

        public const string EnableSelfRegistration = Prefix + ".EnableSelfRegistration";
    }
}