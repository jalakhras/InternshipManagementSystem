﻿using Volo.Abp.Settings;

namespace InternshipManagementSystem.Settings;

public class InternshipManagementSystemSettingDefinitionProvider : SettingDefinitionProvider
{
    public override void Define(ISettingDefinitionContext context)
    {
        //Define your own settings here. Example:
        //context.Add(new SettingDefinition(InternshipManagementSystemSettings.MySetting1));
    }
}