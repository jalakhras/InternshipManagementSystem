﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleToAttribute("InternshipManagementSystem.Domain.Tests")]
[assembly: InternalsVisibleToAttribute("InternshipManagementSystem.TestBase")]