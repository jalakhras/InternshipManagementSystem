﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleToAttribute("InternshipManagementSystem.Application.Tests")]