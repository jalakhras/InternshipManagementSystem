﻿using AutoMapper;

namespace InternshipManagementSystem;

public class InternshipManagementSystemApplicationAutoMapperProfile : Profile
{
    public InternshipManagementSystemApplicationAutoMapperProfile()
    {
        /* You can configure your AutoMapper mapping configuration here.
         * Alternatively, you can split your mapping configurations
         * into multiple profile classes for a better organization. */
    }
}